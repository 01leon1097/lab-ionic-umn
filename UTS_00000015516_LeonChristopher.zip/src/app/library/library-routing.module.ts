import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LibraryPage } from './library.page';

const routes: Routes = [
    {
        path: 'songs',
        component: LibraryPage,
        children: [
            // {
            //     path: '',
            //     loadChildren: './library/library.module#LibraryPageModule'
            // },
            {
                path: ':id',
                loadChildren: './songs/songs.module#SongsPageModule'
            }
                    // ,
                    // {
                    //     path: ':id',
                    //     loadChildren: './songs/place-detail/place-detail.module#PlaceDetailPageModule'
                    // }
            // ,
            // {
            //     path: 'offers',
            //     children: [
            //         {
            //             path: '',
            //             loadChildren: './offers/offers.module#OffersPageModule'
            //         },
            //         {
            //             path: 'new',
            //             loadChildren: './offers/new-offer/new-offer.module#NewOfferPageModule'
            //         },
            //         {
            //             path: 'edit/:placeId',
            //             loadChildren: './offers/edit-offer/edit-offer.module#EditOfferPageModule'
            //         },
            //         {
            //             path: ':placeId',
            //             loadChildren: './offers/offer-bookings/offer-bookings.module#OfferBookingsPageModule'
            //         }
            //     ]
            // }
            ,
            {
                path: '',
                redirectTo: '/library/songs',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/library',
        pathMatch: 'full'
    },  { path: 'favourites', loadChildren: './favourites/favourites.module#FavouritesPageModule' }

];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})


export class LibaryRoutingModule {}