export class Library {
    constructor(
        public id: string,
        public name: string,
        public artist: string,
        public imageUrl: string,
        public songs: Song[]
    ) {}
}

export class Song {
    constructor(
        public id: string,
        public title: string,
        public minute: number,
        public second: number
    ) {}
}