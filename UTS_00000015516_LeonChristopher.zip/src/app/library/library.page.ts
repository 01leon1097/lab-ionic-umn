import { Component, OnInit } from '@angular/core';
import { LibraryService } from '../library/library.service'
import { Library } from '../library/library.model'

@Component({
  selector: 'app-library',
  templateUrl: './library.page.html',
  styleUrls: ['./library.page.scss'],
})
export class LibraryPage implements OnInit {
  loadLibrary: Library[];

  constructor(private libraryService: LibraryService) { }

  ngOnInit() {
    this.loadLibrary = this.libraryService.library;
  }

}
