import { Injectable } from '@angular/core';
import { Library } from './library.model';
import { Song } from './library.model';

@Injectable({
  providedIn: 'root'
})
export class LibraryService {

  private _library: Library[] = [
    new Library(
        'a1',
        'Welcome to the Black Parade',
        'My Chemical Romance',
        'https://i.ibb.co/2vMvvNP/Screen-Shot-2019-09-23-at-13-06-40-PM.png',
        [
            new Song(
                'a1s1',
                'I don\'t love you',
                3,
                59,
            ),
            new Song(
                'a1s2',
                'Teenagers',
                2,
                42,
            ),
            new Song(
                'a1s3',
                'Welcome to the Black Parade',
                5,
                11,
            ),
            new Song(
                'a1s4',
                'This is How I Dissapear',
                3,
                59,
            ),
            new Song(
                'a1s5',
                'House of Wolves',
                 3,
                 59,
            ),
        ]
    ),
    new Library(
        'a2',
        'Love Me / Love Me Not',
        'HONNE',
        'https://i.ibb.co/stR16bb/Screen-Shot-2019-09-23-at-13-06-57-PM.png',
        [
            new Song(
                'a2s1',
                'I might',
                4,
                16,
            ),
            new Song(
                'a2s2',
                'Me & You',
                4,
                4,
            ),
            new Song(
                'a2s3',
                'Day 1',
                3,
                54,
            ),
            new Song(
                'a2s4',
                'I Got YOu',
                3,
                32,
            ),
        ]
    ),
    new Library(
        'a3',
        'Pejantan Tangguh',
        'Sheila on 7',
        'https://i.ibb.co/QQ6MP8J/Screen-Shot-2019-09-23-at-13-06-25-PM.png',
        [
            new Song(
                'a3s1',
                'Pejantan Tangguh',
                3,
                27,
            ),
            new Song(
                'a3s2',
                'Itu Aku',
                4,
                39,
            ),
            new Song(
                'a3s3',
                'Pemuja Rahasia',
                3,
                53,
            ),
            new Song(
                'a3s4',
                'Pilihlah Aku',
                4,
                22,
            ),
            new Song(
                'a3s5',
                'Generasi Patah Hati',
                5,
                6,
            ),
            new Song(
                'a3s6',
                'Ketidakwarasan Padaku',
                3,
                53,
            ),
        ]
    ),
  ];

  get library() {
    return [...this._library];
  }

  constructor() { }

  getallLibrary(){
      return this._library;
  }

  getLibrary(id: string){
    return {...this._library.find(p => p.id === id)};
  }
}
