import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Song, Library } from '../library.model';
import { SongService } from './song.service';
import { LoadingController } from '@ionic/angular';
import { FavoritesService } from '../favourites/favourites.service';

@Component({
  selector: 'app-songs',
  templateUrl: './songs.page.html',
  styleUrls: ['./songs.page.scss'],
})
export class SongsPage implements OnInit {

  constructor(private route:ActivatedRoute,
    private songService:SongService,
    private favService: FavoritesService, 
    private loadingController: LoadingController) { }
  songs: Library;
  id: string;
  favorites = [];

  ngOnInit() {
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('id')) {
        return;
      }
      this.songs = this.songService.getLibrary(paramMap.get('id'));
      console.log(this.songs);
    });
  }

  async addFavorites(song){
    const loading = await this.loadingController.create({
      message: 'Adding to Favorites...',
      duration: 1000
    });
    await loading.present();
    this.favService.addFavorites(song);
  }

  deleteFavorites(song){
    this.favService.deleteFavorites(song);
  }

  isFavorites(song){
    this.favorites = this.favService.getFavorites();
    var z = this.favorites.filter((z) =>  z.id == song.id);
    console.log(song);
    if(z.length == 0){
      return false;
    } else {
      return true;
    }
  }

}
