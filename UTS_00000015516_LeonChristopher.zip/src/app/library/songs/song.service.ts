import { Injectable } from '@angular/core';
import { LibraryService } from '../library.service';

@Injectable({
  providedIn: 'root'
})
export class SongService {

  constructor(private libService: LibraryService) { }

  getLibrary(id: string){
    return {...this.libService.getallLibrary().find(p => p.id === id)};
  }
}
