import { Component, OnInit } from '@angular/core';
import { FavoritesService } from '../favourites/favourites.service';

@Component({
  selector: 'app-favourites',
  templateUrl: './favourites.page.html',
  styleUrls: ['./favourites.page.scss'],
})
export class FavouritesPage implements OnInit {

  constructor(private favService: FavoritesService) { }
  favorites: any;

  ngOnInit() {
    this.favorites = this.favService.getFavorites();
  }

  deleteFavorites(songs){
    this.favService.deleteFavorites(songs);
    this.ngOnInit();
  }

}
