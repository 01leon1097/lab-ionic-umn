import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FavoritesService {

  favorites = []
  constructor() {}

  getFavorites(){
    const local = JSON.parse(localStorage.getItem('Favorites'));
    if(local == null){
      this.favorites = [];
    }else{
      this.favorites = local;
    }
    return this.favorites;
  }

  setFavorites(){
    localStorage.setItem('Favorites', JSON.stringify(this.favorites));
  }

  addFavorites(song){
    this.favorites.push(song);
    this.setFavorites();
    this.getFavorites();
  }

  deleteFavorites(song){
    this.favorites = this.favorites.filter((x) => x.id !== song.id);
    this.setFavorites();
    this.getFavorites();
  }
}
